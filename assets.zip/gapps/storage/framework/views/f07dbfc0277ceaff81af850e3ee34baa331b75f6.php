<div class="sidebar">
    <nav class="sidebar-nav">
        <ul class="nav">

            <?php if($sidebarMenu): ?>

                <?php foreach($sidebarMenu as $menu): ?>
                    <li class="nav-title">
                        <?php echo e($menu['name']); ?>

                    </li>

                    <?php foreach($menu['item'] as $item): ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e($item['link']); ?>">
                              <i class="icon-speedometer"></i> <?php echo e($item['name']); ?>

                            </a>
                        </li>
                    <?php endforeach; ?>

                <?php endforeach; ?>

            <?php endif; ?>
            
        </ul>
    </nav>
</div>