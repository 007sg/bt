<div class="card ripple" >
    <div style="padding: 30px;">
      	<h4><?php echo e(trans('frontend.index.description')); ?></h4>
      	<hr/>
  		
  		<p class="description">
				<?php echo nl2br(@$detail['description']); ?>

			</p>
    </div>
</div>