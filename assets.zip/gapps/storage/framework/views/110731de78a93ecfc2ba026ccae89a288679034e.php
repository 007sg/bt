<ol class="breadcrumb">
    <li class="breadcrumb-item">
        <div>
            <?php echo e(Form::open(['accept-charset'=>'UTF-8', 'url' => route('frontend.search') , 'method' => 'GET','id'=>'main-search'])); ?>

                <div class="input-group">
                   <input type="text" class="form-control" name="q" placeholder="<?php echo e(trans('frontend.index.search')); ?>">
                </div>
            <?php echo e(Form::close()); ?>

        </div>
    </li>
    
    <li class="categories breadcrumb-menu d-sm-down-none">
        <div class="btn-group" role="group" aria-label="Button group with nested dropdown">
            <a class="nav-link dropdown-toggle nav-link" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
                <span class="d-sm-down-none"> <?php echo e(trans('frontend.menu.category')); ?> </span>
            </a>
            <div class="category_list dropdown-menu dropdown-menu-right">

                <ul id="category" class="list-unstyled">
                    <?php foreach($categories as $category): ?>
                        <li class="dropdown-item">
                            <a href="<?php echo e($category['link']); ?>" >
                                <i class="fa fa-google" aria-hidden="true"></i> <?php echo e($category['name']); ?>

                            </a>
                        </li>
                    <?php endforeach; ?>
                </ul>
                
            </div>
        </div>
        <?php if(isset($sidebarMenu)): ?>
            <?php foreach($sidebarMenu as $menu): ?>

                <div class="btn-group" role="group" aria-label="Button group with nested dropdown">
                    <a class="nav-link dropdown-toggle nav-link" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
                        <span class="d-sm-down-none"><?php echo e($menu['name']); ?></span>
                    </a>

                    <div class="dropdown-menu dropdown-menu-right">
                        <?php foreach($menu['item'] as $item): ?>
                            <a class="dropdown-item" href="<?php echo e($item['link']); ?>">
                                <i class="fa fa-link" aria-hidden="true"></i> <?php echo e($item['name']); ?>

                            </a>
                        <?php endforeach; ?>
                    </div>
                </div>    
            <?php endforeach; ?>
        <?php endif; ?>
    </li>
</ol>