<?php if(isset($app) && count($app) > 0): ?>
<?php foreach($app as $top): ?>
  <div class="row">
    <div class="col-6 col-sm-6 col-md-6 ">
      <h5 class="pull-left"><?php echo e($top['name']); ?></h5>
    </div>
    <div class="col-6 col-sm-6 col-md-6 ">
      <a href="<?php echo e(@$top['link']); ?>" title="<?php echo e(@$top['name']); ?>" class="btn btn-success pull-right" style=" margin-bottom: 10px;">
        See More
      </a>
    </div>
  </div>
  <div class="row top-apps">
    <?php foreach($top['apps'] as $key => $app): ?>
        
        <div class="col-6 col-sm-3 col-md-2">
          <div class="card" >
            <div style="padding: 10px;" class="card-img-holder">
              <a href="<?php echo e($app['detail_url']); ?>" title="<?php echo e($app['title']); ?>">
              <img class="b-lazy" 
                   src="<?php echo e(asset('assets/img/ajax-loader.gif')); ?>"
                   data-src="<?php echo e($app['image']['large']); ?>"
                   data-src-small="<?php echo e($app['image']['small']); ?>"
                   alt="<?php echo e($app['title']); ?>"
                   style="padding: 2px;border-radius: 10px;" 
              />
              </a>
            </div>
            <div class="card-block" style="padding: .5rem;background: #fff;    white-space: nowrap;overflow: hidden;    width: 95%;">
                <p>
                <?php echo e(++$key); ?>. <a href="<?php echo e($app['detail_url']); ?>" title="<?php echo e($app['title']); ?>"><?php echo e($app['title']); ?></a> <br/>
                <span>
                  <small class="pull-left">
                  <a href="<?php echo e($app['developer']['link']); ?>" style="color: #263238;">
                    <?php echo e(truncate($app['developer']['name'],8,false,'..')); ?>

                  </a>
                  </small>
                  <small  class="text-success pull-right" ><?php echo e($app['price']); ?></small>
                  </span>
                </p>
            </div>
          </div>
        </div>

    <?php endforeach; ?>
  </div>
<?php endforeach; ?>

<?php else: ?>
<div class="card card-inverse card-danger">
    
    <div class="card-block">
        <?php echo e(trans('frontend.common.no_apps')); ?>

    </div>
</div>
<?php endif; ?>