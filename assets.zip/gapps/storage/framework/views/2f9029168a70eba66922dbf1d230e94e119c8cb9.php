<div class="card ripple" >
    <div style="padding: 30px;">
      	<div id="disqus_thread"></div>
    </div>
</div>