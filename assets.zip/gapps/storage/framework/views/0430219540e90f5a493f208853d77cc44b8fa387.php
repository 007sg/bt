<?php $__env->startSection('stylesheets'); ?>
<style type="text/css">

</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="card card-inverse card-info">
        <div class="card-header">
            Oops!! 404 Not Found
        </div>
        <div class="card-block">
            We're sorry, the requested URL was not found on this server.
            <br/>
            You may try to search again your app.
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>