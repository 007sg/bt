<div class="card ripple" >
    <div style="padding: 30px;">
        <h4><?php echo e(trans('frontend.index.reviews')); ?></h4>
        <hr/>
        <div class="row">
          
          <div class="col-12 col-sm-6 col-md-6 rating">
                <span class="rating-num"><?php echo e(@$detail['reviews']['rate_score']); ?></span>
                <div class="rating-stars">

                  <?php for($i=1;$i<=5;$i++): ?>
                    <span><i class="<?php echo e(@$detail['reviews']['rate_score'] >= $i ? 'active' : ''); ?> icon-star"></i></span>
                  <?php endfor; ?>
                  
                </div>
                <div class="rating-users">
                  <i class="icon-user"></i> <?php echo e($detail['reviews']['rating_count']); ?> total
                </div>
          </div>

              
          <div class="col-12 col-sm-6 col-md-6 histo">

                <?php foreach(@$detail['reviews']['rating_histogram'] as $histo): ?>

                  <?php /**/ 
                    
                    switch ($histo['num']) {
                      case '5':
                          $className = 'five';
                          break;
                      case '4':
                          $className = 'four';
                          break;
                      case '3':
                          $className = 'three';
                          break;
                      case '2':
                          $className = 'two';
                          break;
                      case '1':
                          $className = 'one';
                          break;
                      default:
                          $className = '';
                          break;
                  }

                  /**/ ?>
                  <div class="<?php echo e($className); ?> histo-rate">
                    <span class="histo-star">
                      <i class="active icon-star"></i> <?php echo e($histo['num']); ?>

                    </span>
                    <span class="bar-block">
                      <span id="bar-<?php echo e($className); ?>" class="bar" style="<?php echo e($histo['bar_length']); ?>">
                        <span><?php echo e($histo['bar_number']); ?></span>&nbsp;
                      </span> 
                    </span>
                  </div>
                <?php endforeach; ?>
                
          </div>


          <div class="col">
            <hr/>
            <ul class="list-unstyled">

              <?php if(@$detail['reviews']['comments']): ?>

                <?php foreach($detail['reviews']['comments'] as  $reviews): ?>
                  <li class="media">
                    <?php /* <img class="d-flex mr-3" src="<?php echo e($reviews['image']); ?>" alt="Reviews for <?php echo e($detail['title']); ?>"> */ ?>
                    <img class="b-lazy d-flex mr-3" 
                       src="<?php echo e(asset('assets/img/ajax-loader.gif')); ?>"
                       data-src="<?php echo e($reviews['image']); ?>"
                       alt="<?php echo e($detail['title']); ?>"
                    />
                    <div class="media-body">
                      <h6 class="mt-0 mb-1"><?php echo e($reviews['author']); ?>

                      <small> Published date: <?php echo e($reviews['published_date']); ?></small>
                      </h6>
                      <p><?php echo nl2br($reviews['comments']); ?></p>
                    </div>
                  </li>
                <?php endforeach; ?>
              <?php else: ?>
                <li>
                  <?php echo e(trans('frontend.common.no_comments')); ?>

                </li>
              <?php endif; ?>
              
            </ul>
          </div>

        </div>
    </div>
</div>