<footer class="app-footer">
    <?php echo trans('frontend.footer.copyright'); ?>

      <span class="float-right">
        <a href="<?php echo e(url('/')); ?>">
            <?php echo e(trans('frontend.footer.home')); ?>

        </a> |
        <a href="<?php echo e(route('page.about')); ?>">
            <?php echo e(trans('frontend.footer.about_us')); ?>

        </a> |
        <a href="<?php echo e(route('page.dmca')); ?>">
            <?php echo e(trans('frontend.footer.dmca')); ?>

        </a> |
        <a href="<?php echo e(route('page.privacy.policy')); ?>">
            <?php echo e(trans('frontend.footer.privacy_policy')); ?>

        </a> |
        <a href="<?php echo e(route('page.contactus')); ?>">
            <?php echo e(trans('frontend.footer.contact_us')); ?>

        </a>
    </span>

</footer>