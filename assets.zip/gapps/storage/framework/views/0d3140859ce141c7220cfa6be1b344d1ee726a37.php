<?php $__env->startSection('stylesheets'); ?>
<style type="text/css">

</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="container">
  <div class="animated fadeIn">
        <div class="row">
            <div class="col-sm-12 col-md-12">
                <div class="card">
                    <div class="card-header">
                         <?php echo e(trans('frontend.footer.contact_us')); ?>

                    </div>
                    <div class="card-block">

                        <div class="row">
                            <div class="col-sm-6 offset-sm-3">

                                <?php if(Session::has('message')): ?>
                                    <div class="alert alert-succss">
                                      <?php echo e(Session::get('message')); ?>

                                    </div>
                                <?php endif; ?>
                                <ul>
                                    <?php foreach($errors->all() as $error): ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; ?>
                                </ul>

                                <?php echo e(Form::open(['url' => route('page.submit.contact'),'method' => 'POST'])); ?>

                                  <div class="form-group">
                                      <label for="name"><?php echo e(trans('frontend.contact.name')); ?></label>
                                      <input type="text" class="form-control" id="name" name="name" placeholder="Enter your name">
                                  </div>

                                  <div class="form-group">
                                      <label for="email_address"><?php echo e(trans('frontend.contact.email')); ?></label>
                                      <input type="text" class="form-control" id="email_address" name="email_address" placeholder="Enter your email address">
                                  </div>

                                  <div class="form-group">
                                      <label for="message"><?php echo e(trans('frontend.contact.message')); ?></label>
                                      <textarea id="message"  class="form-control" name="message" placeholder="Enter your message" style="height: 200px;"></textarea>
                                  </div>


                                  <div class="form-group">
                                    <button type="submit" class="btn btn-sm btn-primary">
                                      <i class="fa fa-dot-circle-o"></i> <?php echo e(trans('frontend.contact.submit')); ?>

                                    </button>
                                  </div>
                                <?php echo e(Form::close()); ?>


                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
        
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<script type="text/javascript">
  $(document).ready(function($){
     
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>