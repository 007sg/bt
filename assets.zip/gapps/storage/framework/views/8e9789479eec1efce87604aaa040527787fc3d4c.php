<ol class="breadcrumb">
    <li >
      <div class="input-group">
        <input type="text" class="form-control" placeholder="Search from apps store...">
      </div>
    </li>
</ol>