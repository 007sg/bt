<?php /* START TOP BANNER */ ?>
<?php $__env->startSection('ads_top_banner'); ?>
	
	<div class="col-12 col-md-auto">
		<div class="card ripple text-center" style="min-height: 90px;">
	    
	      	<?php /* PASTE YOUR ADS FOR TOP BANNER HERE  */ ?>
	      	ADS TOP BANNER HERE
	      	
	    </div>
	</div>


<?php $__env->stopSection(); ?>
<?php /* END TOP BANNER */ ?>



<?php /* START BOTTOM BANNER */ ?>
<?php $__env->startSection('ads_bottom_banner'); ?>

	<div class="col-12 col-md-auto">
		<div class="card ripple text-center" style="min-height: 90px;">
	   	<?php /* PASTE YOUR ADS FOR BOTTOM BANNER HERE  */ ?>
	   	ADS BOTTOM BANNER HERE
		</div>
	</div>

<?php $__env->stopSection(); ?>
<?php /* END BOTTOM BANNER */ ?>



<?php /* START SIDEBAR BANNER */ ?>
<?php $__env->startSection('ads_sidebar_banner'); ?>
	<div class="col-6 col-sm-4 col-md-12">
	        <div class="card ripple" >
			    <?php /* PASTE YOUR ADS FOR SIDEBAR BANNER HERE  */ ?>
			   	ADS SIDEBAR BANNER HERE
			</div>
	</div>
<?php $__env->stopSection(); ?>
<?php /* END SIDEBAR BANNER */ ?>