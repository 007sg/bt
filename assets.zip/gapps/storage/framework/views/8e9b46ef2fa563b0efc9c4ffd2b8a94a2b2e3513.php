<?php if(@$detail['screenshots']): ?>
    <div class="card ripple" >
        <div style="padding: 30px;">
          	<h4><?php echo e(trans('frontend.index.screenshot')); ?></h4>
          	<hr/>
      		
      		<p class="description">
  				<div id="screenshots" class="owl-carousel owl-theme">
		           	<?php foreach($detail['screenshots'] as $img): ?>
		           		<div class="item">
							<?php /* <img class="img-fluid" src="<?php echo e($img); ?>"> */ ?>
							<img class="b-lazy" 
							   src="<?php echo e(asset('assets/img/ajax-loader.gif')); ?>"
							   data-src="<?php echo e($img); ?>"
							   alt="<?php echo e($detail['title']); ?>"
							/>
						</div>
		           	<?php endforeach; ?>

		        </div>
  			</p>
        </div>
    </div>
<?php endif; ?>