<?php if(@$detail['similar_apps']): ?>
    
    <?php if(count($detail['similar_apps']) > 0): ?>
        <label><?php echo e(trans('frontend.index.similar')); ?> </label>
        <?php /* <button class="btn btn-block btn-sm btn-success" style=" margin-bottom: 10px;">See More</button> */ ?>
        <br/>

        <div class="row no-gutters">

            <?php foreach(@$detail['similar_apps'] as $key => $app): ?>
            <div class="col-6 col-sm-4 col-md-12">
                <div class="card ripple" >
                    <div style="padding: 10px;">
                        
                        <div class="col-12 col-sm-12 col-md-12 app-image text-center">
                            <a href="<?php echo e($app['detail_url']); ?>" title="<?php echo e($app['title']); ?>">
                            <img class="b-lazy" 
                                   src="<?php echo e(asset('assets/img/ajax-loader.gif')); ?>"
                                   data-src="<?php echo e($app['image']['large']); ?>"
                                   data-src-small="<?php echo e($app['image']['small']); ?>"
                                   alt="<?php echo e($app['title']); ?>"
                                   style="padding: 2px;border-radius: 10px;" 
                              />
                            </a>
                        </div>
                        <div class="card-block" style="padding: .5rem;background: #fff;white-space: nowrap;overflow: hidden;width: 100%;">
                            <p>
                                <?php echo e(++$key); ?>. <a href="<?php echo e($app['detail_url']); ?>" title="<?php echo e($app['title']); ?>"><?php echo e($app['title']); ?></a> <br/>
                                <span>
                                    <small class="pull-left">
                                        <a href="<?php echo e($app['developer']['link']); ?>" style="color: #263238;">
                                            <?php echo e(truncate($app['developer']['name'],8,false,'..')); ?>

                                        </a>
                                    </small>
                                    <small  class="text-success pull-right" ><?php echo e($app['price']); ?></small>
                                </span>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; ?>
       
        </div>
    <?php endif; ?>
<?php endif; ?>