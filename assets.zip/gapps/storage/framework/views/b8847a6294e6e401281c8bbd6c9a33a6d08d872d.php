<?php $__env->startSection('stylesheets'); ?>
<style type="text/css">
  .top-apps .card-block a {
      color: #383838 !important;
  }
  .top-apps .card-block a:hover {
      color: #737373 !important;
  }

  .top-apps .card-img-holder:hover {
        background: #cecece;
  }
</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="container">

<?php if(isset($list) && count($list) > 0): ?>
  <div class="row">
    <div class="col-12 col-sm-12 col-md-12 ">
      <h5 ><?php echo e($developerId); ?></h5>
    </div>
  </div>
  <div class="row ">
    <?php foreach($list as $key => $app): ?>
        
        <div class="col-6 col-sm-3 col-md-2">
          <div class="card" >
            <div style="padding: 10px;" class="card-img-holder">
              <img class="b-lazy" 
                   src="<?php echo e(asset('assets/img/ajax-loader.gif')); ?>"
                   data-src="<?php echo e($app['image']['large']); ?>"
                   data-src-small="<?php echo e($app['image']['small']); ?>"
                   alt="<?php echo e($app['title']); ?>"
                   style="padding: 2px;border-radius: 10px;" 
              />
            </div>
            <div class="card-block" style="padding: .5rem;background: #fff;    white-space: nowrap;overflow: hidden;    width: 95%;">
                <p>
                <?php echo e(++$key); ?>. <a href="<?php echo e($app['detail_url']); ?>" title="<?php echo e($app['title']); ?>"><?php echo e($app['title']); ?></a> <br/>
                <span>
                  <small class="pull-left">
                    <a href="<?php echo e($app['developer']['link']); ?>" title="<?php echo e($app['developer']['name']); ?>" style="color: #5a5a5a !important;">
                      <?php echo e(truncate($app['developer']['name'],8,false,'..')); ?>

                    </a>
                  </small>
                  <small  class="text-success pull-right" ><?php echo e($app['price']); ?></small>
                  </span>
                </p>
            </div>
          </div>
        </div>

    <?php endforeach; ?>
  </div>

<?php else: ?>
<div class="card card-inverse card-danger">
    
    <div class="card-block">
        No top Applications Found.
    </div>
</div>
<?php endif; ?>

</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<script type="text/javascript">
  $(document).ready(function($){
      // Initialize
      Blazy();
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>