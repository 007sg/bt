<?php $__env->startSection('content'); ?>

<div class="container">
  <?php echo $__env->make('frontend.index.render', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<script type="text/javascript">
  $(document).ready(function($){
      // Initialize
      Blazy();
  });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('frontend.layouts.main', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>