<?php

/**
 * App\Http\Controllers\Frontend\IndexController
 * 
 * __DESCRIPTION__
 *
 * @package GAPPS
 * @category IndexController
 * @author  Anthony Pillos <dev.anthonypillos@gmail.com>
 * @copyright Copyright (c) 2017
 * @version v1
 */


namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Cache;
use Lib\Api\GoogleApps;
class IndexController extends Controller
{

    private $request;
    private $gapps;

 	/**
    * __construct()
    * Initialize our Class Here for Dependecy Injection
    *
    * @return void
    * @access  public
    */
    public function __construct(Request $request,GoogleApps $gapps)
    {
        $this->request = $request;
        $this->gapps   = $gapps;
    }


    /**
    * getIndex()
    *
    * @return void
    * @access  public
    */
    public function getIndex()
    {
        $app = $this->gapps->topApps();
        return view('frontend.index.index')->with(compact('app'));
    }

    /**
    * getDetail()
    *
    * @return void
    * @access  public
    */
    public function getDetail($slug = null)
    {
        if(!request()->has('appid'))
            return redirect()->route('frontend.index');

        $appId = request()->get('appid');
        $detail = $this->gapps->details($appId);
    
        $currentURl = route('frontend.detail',str_slug(htmlentities($slug))).'?appid='.$appId;
        return view('frontend.index.detail')->with(compact('detail','appId','currentURl'));
    }

    /**
    * getDeveloper()
    *
    * @return void
    * @access  public
    */
    public function getDeveloper($developerId)
    {
        $list = $this->gapps
                    ->setOptions(['lang' => 'en'])
                    ->developerLists($developerId);

        return view('frontend.index.developer')->with(compact('list','developerId'));
    }

    /**
    * getCategory()
    *
    * @return void
    * @access  public
    */
    public function getCategory($categoryId,$collection = null,$type = null)
    {
        $app = $this->gapps->byCategory($categoryId,$collection,$type);
        // pre($app);exit;
        $catName = str_replace('_', ' ', $categoryId);
        $categoryName = ucwords(strtolower($catName));
        return view('frontend.index.category')->with(compact('app','categoryName'));
    }

   /**
    * getSearch()
    *
    * @return void
    * @access  public
    */
    public function getSearch()
    {
        
        if( !$this->request->has('q') )
            return redirect()->route('frontend.index');

        $searchQ = e($this->request->get('q'));

        $string     = implode("",explode("\\",$searchQ));
        $searchQ    = htmlentities(stripslashes(trim($searchQ)));

        $topApps = $this->gapps->search($searchQ);
        return view('frontend.index.collection')->with(compact('topApps','searchQ'));
        
    }

   /**
    * getAppCollection()
    *
    * @return void
    * @access  public
    */
    public function getAppCollection($identifier)
    {
        $topApps = $this->gapps->lists($identifier);
        return view('frontend.index.collection')->with(compact('topApps'));
        
    }

    /**
    * getDownloadApp()
    *
    * @return void
    * @access  public
    */
    public function getDownloadApp($slug)
    {
        if( !$this->request->has('token') )
            return abort(404);

        parse_str(base64_decode($this->request->get('token')),$token);

        if(isset($token['id']))
        {
            $detail = Cache::get( str_slug($token['id']));
            if(!$detail)
                return abort(404);
            
            $app = Cache::get('top_apps');
            // pre($app);exit;
            return view('frontend.index.download-detail')->with(compact('detail','app'));
        }
        return abort(404);
    }
}