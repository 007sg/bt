<?php

/**
 * App\Http\Controllers\Frontend\PageController
 * 
 * __DESCRIPTION__
 *
 * @package GAPPS
 * @category PageController
 * @author  Anthony Pillos <dev.anthonypillos@gmail.com>
 * @copyright Copyright (c) 2017
 * @version v1
 */


namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Mail;

class PageController extends Controller
{

    private $request;
    private $gapps;

 	/**
    * __construct()
    * Initialize our Class Here for Dependecy Injection
    *
    * @return void
    * @access  public
    */
    public function __construct(Request $request)
    {
        $this->request = $request;
    }


    /**
    * About us
    *
    */
    public function getAboutUs()
    {
       return view('frontend.pages.about-us');
    }

    /**
    * DMCA
    *
    */
    public function getDmca()
    {
       return view('frontend.pages.dmca');
    }

    /**
    * Privacy Policy
    *
    */
    public function getPrivacyPolicy()
    {
       return view('frontend.pages.privacy-policy');
    }

    /**
    * Privacy Policy
    *
    */
    public function getContactUs()
    {
       return view('frontend.pages.contact-us');
    }


    /**
    * Process Contact uS
    *
    */
    public function postContactUs()
    {
       
       $this->validate($this->request, [
            'name'          => 'required|min:2',
            'email_address' => 'required|email',
            'message'       => 'required|min:10'
        ]);

       $data = $this->request->all();

       Mail::send('emails.contact',
            array(
                'name' => $this->request->get('name'),
                'email' => $this->request->get('email_address'),
                'user_message' => $this->request->get('message')
            ), function($message) use ($data) 
        {

            $message->from($data['email_address']);
            $message->to(env('MAIL_RECEIVE_EMAIL_INQUIRY_FROM_CONTACTUS'), 'Admin')->subject(trans('frontend.general.site_title').' Contact US Form');
        });

      return redirect()->route('page.contactus')->with('message', 'Thanks for contacting us!');
    }
}