<?php

/**
 * App\Http\Middleware\SentinelAdminCheck
 * 
 * Middleware for checking the current user login
 *
 * @package MyCMS
 * @category SentinelAdminCheck
 * @author  Anthony Pillos <dev.anthonypillos@gmail.com>
 * @copyright Copyright (c) 2016
 * @version v1
 */


namespace App\Http\Middleware;

use Closure;
use Sentinel;

class SentinelAdminCheck
{
    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @param  string|null  $guard
     * @return mixed
     */
    public function handle($request, Closure $next, $guard = null)
    {

        $user = Sentinel::getUser();
        if ($user) 
        {   
            if ( $user->hasAccess('admin.login') )
                return $next($request);
        }
        $url = route('backend.login').'?return-url=' . $request->url();
        return redirect( $url );
    }
}
