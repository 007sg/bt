<?php

/*
|--------------------------------------------------------------------------
| Application Routes
|--------------------------------------------------------------------------
|
| This route group applies the "web" middleware group to every route
| it contains. The "web" middleware group is defined in your HTTP
| kernel and includes session state, CSRF protection, and more.
|
*/


//Clear Cache facade value:
Route::get('/clear-cache', function() {
    $exitCode = Artisan::call('cache:clear');
    return view('frontend.common.cache')->with('message','Cache facade value cleared');
});

//Reoptimized class loader:
Route::get('/optimize', function() {
    $exitCode = Artisan::call('optimize');
    return view('frontend.common.cache')->with('message','Reoptimized class loader');
});

//Clear Route cache:
Route::get('/route-cache', function() {
    $exitCode = Artisan::call('route:cache');
    return view('frontend.common.cache')->with('message','Route cache cleared');
});

//Clear View cache:
Route::get('/view-clear', function() {
    $exitCode = Artisan::call('view:clear');
    return view('frontend.common.cache')->with('message','View cache cleared');
});

//Clear Config cache:
Route::get('/config-cache', function() {
    $exitCode = Artisan::call('config:cache');
    return view('frontend.common.cache')->with('message','Clear Config cleared');
});

Route::get('demo', function() {
    

    $str = 'https://play.google.com/store/apps/details?id=com.facebook.orca&hl=en&gl=us';

    $urlArr = parse_url($str);

    $s = encrypt($urlArr['query']);
    pre( $s );
    pre( decrypt($s) );

    exit;
});


Route::group( ['prefix' => '/', 'namespace' => 'Frontend'], function() {

    Route::controller( 'page', 'PageController',
        [
            'getAboutUs'       => 'page.about',
            'getDmca'          => 'page.dmca',
            'getPrivacyPolicy' => 'page.privacy.policy',
            'getContactUs'     => 'page.contactus',
            'postContactUs'    => 'page.submit.contact',
        ]
    );

    // // INDEX PAGE
    Route::controller( '/', 'IndexController',
        [
            'getIndex'         => 'frontend.index',
            'getDetail'        => 'frontend.detail',
            'getDeveloper'     => 'frontend.developer',
            'getCategory'      => 'frontend.category',
            'getAppCollection' => 'frontend.collection',
            'getSearch'        => 'frontend.search',
            'getDownloadApp'   => 'frontend.download'
        ]
    );

});