<?php

/**
* pre()
* short hand for printing array/string data
*
* @return array/string
**/
if(!function_exists('pre')){
	function pre($str) {
		echo '<pre/>';
		return print_r($str);
	}
}

/**
* truncate()
* truncate string
*
* @return void
**/
if(!function_exists('truncate')){
    function truncate($string = null, $length = 60 , $middle = false,$etc = ' [...]',$charset='UTF-8',  $break_words = false) {
        if ($length == 0)
            return '';
     
        if (mb_strlen($string) > $length) {
            $length -= min($length, mb_strlen($etc));
            if (!$break_words && !$middle) {
                $string = preg_replace('/\s+?(\S+)?$/', '', mb_substr($string, 0, $length+1));
            }
            if(!$middle) {
                return mb_substr($string, 0, $length,$charset) . $etc;
            } else {
                return mb_substr($string, 0, $length/2,$charset) . $etc . mb_substr($string, -$length/2);
            }
        } else {
            return $string;
        }
    }
}



/**
* arrayKeywordsToCommaString()
*
* @return string
**/
if (!function_exists('arrayKeywordsToCommaString')) {
  function arrayKeywordsToCommaString($data)
  {
        if($data == '')
            return '';
        
        $keywordArray = [];
        foreach ($data as $key => $val) {
            $keywordArray[] = $val['text'];
        }
        return implode(',', $keywordArray);
  }
}


/**
* commaStringToArrayKeywords()
*
* @return string
**/
if (!function_exists('commaStringToArrayKeywords')) {
  function commaStringToArrayKeywords($data)
  {
        $keyArr = explode(',', $data);
        $keywordArray = [];
        foreach ($keyArr as $key => $word) {
            $keywordArray[] = ['text' => $word];
        }
        return $keywordArray;
  }
}


/**
* numberInAString()
*
* @return string
**/
if (!function_exists('numberInAString')) {

  function numberInAString($string)
  {
      preg_match_all('/([0-9]+\.[0-9]+)/', $string, $matches);
      return is_array($matches[0]) ? @$matches[0][0] : 5;
  }
}