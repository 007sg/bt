<?php

$env = env('APP_ENV');