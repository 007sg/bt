<?php

/**
 * Lib\ViewComposers\Frontend
 *
 * @package iYOOTOOB
 * @category Frontend
 * @author  Anthony Pillos <dev.anthonypillos@gmail.com>
 * @copyright Copyright (c) 2017
 * @version v1
 */

namespace Lib\ViewComposers;

use Illuminate\Http\Request;
use Illuminate\View\View;
use Cache;

class Frontend
{

    /**
     * Bind data to the view.
     *
     * @param  View  $view
     * @return void
     */
    public function compose(View $view)
    {
        
    }
}