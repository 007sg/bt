<?php

/**
 * Lib\ViewComposers\CommonView
 *
 * @package iYOOTOOB
 * @category CommonView
 * @author  Anthony Pillos <dev.anthonypillos@gmail.com>
 * @copyright Copyright (c) 2017
 * @version v1
 */

namespace Lib\ViewComposers;

use Illuminate\Http\Request;
use Illuminate\View\View;
use Cache;

class CommonView
{

    /**
     * Bind data to the view.
     *
     * @param  View  $view
     * @return void
     */
    public function compose(View $view)
    {

        $view->with('sidebarMenu', $this->sidebarMenu());
        $view->with('categories', $this->categories());

    }


    /**
    * sidebarMenu()
    *
    * @return array
    * @access  private
    **/
    private function sidebarMenu()
    {
        $menuArr = [

            'top_charts' => [
                'name' => trans('frontend.menu.top_chart'),
                'item' => [
                    [
                        'name' => trans('frontend.menu.top_free_apps'),
                        'link' => route('frontend.collection','topselling_free')
                    ],
                    [
                        'name' => trans('frontend.menu.top_paid_apps'),
                        'link' => route('frontend.collection','topselling_free')
                    ],
                    [
                        'name' => trans('frontend.menu.top_grossing_apps'),
                        'link' => route('frontend.collection','topselling_free')
                    ]
                ]
            ],
            'new_releases' => [
                'name' => trans('frontend.menu.new_release'),
                'item' => [
                    [
                        'name' => trans('frontend.menu.top_new_free'),
                        'link' => route('frontend.collection','topselling_new_free')
                    ],
                    [
                        'name' => trans('frontend.menu.top_new_paid'),
                        'link' => route('frontend.collection','topselling_new_paid')
                    ]
                ]
            ]
        ];
        return $menuArr;
    }


    private function categories()
    {
        $catArray = [
           'ANDROID_WEAR'        => 'ANDROID_WEAR',
           'ART_AND_DESIGN'      => 'ART_AND_DESIGN',
           'AUTO_AND_VEHICLES'   => 'AUTO_AND_VEHICLES',
           'BEAUTY'              => 'BEAUTY',
           'BOOKS_AND_REFERENCE' => 'BOOKS_AND_REFERENCE',
           'BUSINESS'            => 'BUSINESS',
           'COMICS'              => 'COMICS',
           'COMMUNICATION'       => 'COMMUNICATION',
           'DATING'              => 'DATING',
           'EDUCATION'           => 'EDUCATION',
           'ENTERTAINMENT'       => 'ENTERTAINMENT',
           'EVENTS'              => 'EVENTS',
           'FINANCE'             => 'FINANCE',
           'FOOD_AND_DRINK'      => 'FOOD_AND_DRINK',
           'HEALTH_AND_FITNESS'  => 'HEALTH_AND_FITNESS',
           'HOUSE_AND_HOME'      => 'HOUSE_AND_HOME',
           'LIBRARIES_AND_DEMO'  => 'LIBRARIES_AND_DEMO',
           'LIFESTYLE'           => 'LIFESTYLE',
           'MAPS_AND_NAVIGATION' => 'MAPS_AND_NAVIGATION',
           'MEDICAL'             => 'MEDICAL',
           'MUSIC_AND_AUDIO'     => 'MUSIC_AND_AUDIO',
           'NEWS_AND_MAGAZINES'  => 'NEWS_AND_MAGAZINES',
           'PARENTING'           => 'PARENTING',
           'PERSONALIZATION'     => 'PERSONALIZATION',
           'PHOTOGRAPHY'         => 'PHOTOGRAPHY',
           'PRODUCTIVITY'        => 'PRODUCTIVITY',
           'SHOPPING'            => 'SHOPPING',
           'SOCIAL'              => 'SOCIAL',
           'SPORTS'              => 'SPORTS',
           'TOOLS'               => 'TOOLS',
           'TRAVEL_AND_LOCAL'    => 'TRAVEL_AND_LOCAL',
           'VIDEO_PLAYERS'       => 'VIDEO_PLAYERS',
           'WEATHER'             => 'WEATHER',
           'APP_WIDGETS'         => 'APP_WIDGETS',
           'GAME'                => 'GAME',
           'GAME_ACTION'         => 'GAME_ACTION',
           'GAME_ADVENTURE'      => 'GAME_ADVENTURE',
           'GAME_ARCADE'         => 'GAME_ARCADE',
           'GAME_BOARD'          => 'GAME_BOARD',
           'GAME_CARD'           => 'GAME_CARD',
           'GAME_CASINO'         => 'GAME_CASINO',
           'GAME_CASUAL'         => 'GAME_CASUAL',
           'GAME_EDUCATIONAL'    => 'GAME_EDUCATIONAL',
           'GAME_MUSIC'          => 'GAME_MUSIC',
           'GAME_PUZZLE'         => 'GAME_PUZZLE',
           'GAME_RACING'         => 'GAME_RACING',
           'GAME_ROLE_PLAYING'   => 'GAME_ROLE_PLAYING',
           'GAME_SIMULATION'     => 'GAME_SIMULATION',
           'GAME_SPORTS'         => 'GAME_SPORTS',
           'GAME_STRATEGY'       => 'GAME_STRATEGY',
           'GAME_TRIVIA'         => 'GAME_TRIVIA',
           'GAME_WORD'           => 'GAME_WORD',
           'FAMILY'              => 'FAMILY',
           'FAMILY_ACTION'       => 'FAMILY_ACTION',
           'FAMILY_BRAINGAMES'   => 'FAMILY_BRAINGAMES',
           'FAMILY_CREATE'       => 'FAMILY_CREATE',
           'FAMILY_EDUCATION'    => 'FAMILY_EDUCATION',
           'FAMILY_MUSICVIDEO'   => 'FAMILY_MUSICVIDEO',
           'FAMILY_PRETEND'      => 'FAMILY_PRETEND',
        ];
        $categoryArr = [];
        foreach ($catArray as $key => $cat) {

            $catName = str_replace('_', ' ', $cat);
            $modName = ucwords(strtolower($catName));

            $categoryArr[] = [
             
                'name'  => $modName,
                'link'  => route('frontend.category',$cat)
            ];
        }
        return $categoryArr;
    }

}