@extends('frontend.layouts.main')

@section('stylesheets')
<style type="text/css">

</style>
@stop
@section('content')

<div class="container">
    <div class="card card-inverse card-info">
        <div class="card-header">
            Oops!! 404 Not Found
        </div>
        <div class="card-block">
            We're sorry, the requested URL was not found on this server.
            <br/>
            You may try to search again your app.
        </div>
    </div>
</div>


@stop

@section('scripts')

@stop