@extends('frontend.layouts.main')

@section('stylesheets')
<style type="text/css">

</style>
@stop
@section('content')

<div class="container">
    <div class="card card-inverse card-info">
        <div class="card-header">
            Something Went Wrong!
        </div>
        <div class="card-block">
            Checking server at the moment.
        </div>
    </div>
</div>

@stop

@section('scripts')

@stop