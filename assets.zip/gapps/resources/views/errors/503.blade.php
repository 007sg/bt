@extends('frontend.layouts.main')

@section('stylesheets')
<style type="text/css">

</style>
@stop
@section('content')

<div class="container">
    <div class="card card-inverse card-info">
        <div class="card-header">
            Scheduled Maintenance
        </div>
        <div class="card-block">
            We will be back, after a minute.
        </div>
    </div>
</div>


@stop

@section('scripts')

@stop