@extends('backend.common.layouts.main')

@section('content')
<div class="row">
    <div class="col-xs-12">
        <div class="card">
            <div class="card-header">
                <div class="card-title">
                    <div class="title">WELCOME TO {{ @$configuration['site_title'] }}</div>
                    <div class="description">{{ @$configuration['site_description'] }}</div>
                </div>
            </div>

            {{-- <div class="card-body">
                <div class="row">
                    <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
                        <a href="#">
                            <div class="card red summary-inline">
                                <div class="card-body">
                                    <i class="icon fa fa-users fa-3x"></i>
                                    <div class="content">
                                        <div class="title">{{ @$totalUsers }}</div>
                                        <div class="sub-title">Total Users</div>
                                    </div>
                                    <div class="clear-both"></div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
                        <a href="#">
                            <div class="card blue summary-inline">
                                <div class="card-body">
                                    <i class="icon fa fa-youtube fa-3x"></i>
                                    <div class="content">
                                        <div class="title">{{ @$totalVideos }}</div>
                                        <div class="sub-title">Total Videos</div>
                                    </div>
                                    <div class="clear-both"></div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-6 col-xs-12">
                        <a href="#">
                            <div class="card green summary-inline">
                                <div class="card-body">
                                    <i class="icon fa fa-play fa-3x"></i>
                                    <div class="content">
                                        <div class="title">{{ @$totalChannels }}</div>
                                        <div class="sub-title">Total Channels</div>
                                    </div>
                                    <div class="clear-both"></div>
                                </div>
                            </div>
                        </a>
                    </div>
                </div>
            </div> --}}
        </div>
    </div>
</div>



{{-- <div class="row">
    <div class="col-xs-12">
        <div class="card">
            <div class="card-header">
                <div class="card-title">
                    <div class="title">Summary Information</div>
                </div>
            </div>
            <div class="card-body">

                <div class="col-xs-12 col-md-12">
                    
                    <div class="sub-title">Top 10 Video Views</div>
                    <div>
                        <table class="table">
                            <thead>
                                <tr>
                                    <th >Image</th>
                                    <th >Name</th>
                                    <th class="text-center" width="10">Views</th>
                                </tr>
                            </thead>
                            <tbody>
                                @if(isset($videoViews) && !$videoViews->isEmpty())
                                    @foreach($videoViews as $data)
                                        <tr>
                                            <td>

                                                <a uib-tooltip="{{ $data->statisticable->title }}" class="hand" href="{{ $data->statisticable->backend_detail_url }}">
                                                <div uib-tooltip="{{ $data->statisticable->title }}">
                                                    <img src="{{ $data->statisticable->image_url }}" width="80" class="img-responsive" />
                                                </div>
                                                </a>
                                            </td>
                                            <td>
                                                <a uib-tooltip="{{ $data->statisticable->title }}" class="hand" href="{{ $data->statisticable->backend_detail_url }}">
                                                    {{ truncate($data->statisticable->title,47) }}
                                                </a>
                                            </td>
                                            <td class="text-center">{{ $data->views }}</td>
                                        </tr>
                                    @endforeach
                                @else
                                    <tr  align="center">
                                        <td colspan="3">No Video Views </td>
                                    </tr>
                                @endif
                            </tbody>
                        </table>
                       
                    </div>
                </div>

            </div>
        </div>
    </div>
</div> --}}
@stop