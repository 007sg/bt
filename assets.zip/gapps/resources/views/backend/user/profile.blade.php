@extends('backend.common.layouts.main')

@section('content')

<div class="row">
    <div class="col-xs-12">
        <div class="card">
            <div class="card-header">
                <div class="card-title">
                    <div class="title">My Profile | Yow!, {{ @$userDetails->full_name }}</div>
                    {{-- <div class="description">Show All Posts in your blog</div> --}}
                </div>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-xs-12 col-md-12">
                        @if($errors->has())

                            <div class="alert alert-danger fade in text-left m-t-10">
                                <button class="close" data-dismiss="alert"><span>×</span></button>
                                @foreach ($errors->all() as $error)
                                    <p><i class="fa fa-warning"></i> {{ $error }}</p>
                                @endforeach
                            </div>

                        @endif
                        @if(Session::get('success'))

                            <div class="alert alert-success fade in text-left m-t-10">
                                <button class="close" data-dismiss="alert"><span>×</span></button>
                                <p><i class="fa fa-check"></i> {{ Session::get('success') }}</p>
                            </div>
                        @endif
                        {{ Form::open(['accept-charset'=>'UTF-8', 'url' => route('backend.profile.update') , 'method' => 'POST']) }}
                          <div class="form-group">
                            <label for="exampleInputEmail1">Firstname</label>
                            <input type="text" class="form-control" name="first_name" placeholder="Firstname" value="{{ @$userDetails->first_name }}">
                          </div>
                          <div class="form-group">
                            <label for="exampleInputEmail1">Lastname</label>
                            <input type="text" class="form-control" name="last_name" placeholder="Lastname" value="{{ @$userDetails->last_name }}">
                          </div>
                          <div class="form-group">
                            <label for="exampleInputEmail1">Email address</label>
                            <input type="email" class="form-control" name="email" placeholder="Email Address" value="{{ @$userDetails->email }}">
                          </div>
                          <div class="form-group">
                            <label for="exampleInputEmail1">Username</label>
                            <input type="text" class="form-control" name="username" placeholder="Username" value="{{ @$userDetails->username }}">
                          </div>
                          <div class="form-group">
                            <label for="exampleInputPassword1">Password</label>
                            <input type="password" class="form-control" name="password" placeholder="*********" >
                            <input type="hidden" class="form-control" name="is_backend" value="1">
                            <input type="hidden" class="form-control" name="token_id" value="{{ @$userDetails->id }}" >
                          </div>
                          <button type="submit" class="btn btn-brown">Update Profile</button>
                        {{ Form::close() }}
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

@stop