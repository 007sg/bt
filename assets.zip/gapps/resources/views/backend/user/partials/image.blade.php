<div class="wrap-uploader" id="div-uploader" ng-cloak>
	<div id="uploader_front" class="col-xs-12">
			<h4 class="text-center"><i class="fa fa-file-image-o"></i> Upload Image</h4>

			<div ng-if="details.image" class="col-lg-6 col-sm-8 col-xs-12 col-sm-custom" style="margin-left: -25%;left: 50%;">
		        <a href="#">
		             <img  class="thumbnail img-responsive">
		        </a>
		        <button type="button" class="btn btn-xs btn-block btn-info">Change Cover</button>
		    </div>
			<div class="uploader" file-uploader is-multiple="false" identifier="{{ UPLOAD_AVATAR }}" style="width: 100%">
				<div ng-if="!details.image">
					<div  ng-if="uploads.status == 0 ? true : false" class="drop-zone custom-dropzone-height">

						<div class="content custom-content">
							<div class="img-arrow">
						    	<i class="fa fa-arrow-circle-o-up"></i>
						  	</div>

						  	<div>{[ details.file.name || details.file.webkitRelativePath || 'DRAG & DROP' | truncateMiddle:30  ]}</div>
						    <div class="btn-browse">
								Browse
								<input name="file" id="fileuploader" file-uploader is-multiple="false" identifier="{{ UPLOAD_AVATAR }}" class="btn btn-info input-uploader" type="file">
							</div>
						</div>
					</div>

					<div  ng-if="uploads.status == 1 ? true : false" class="drop-zone custom-dropzone-height progressbar">
						<div class="content custom-content">
							<div class="img-arrow">
						    	<i class="fa fa-arrow-circle-o-up"></i>
						  	</div>
						  	{[ details.file.name || details.file.webkitRelativePath || 'In Progress'  | truncateMiddle:30  ]}
							<div class="progress">
					            <div class="progress-bar" role="progressbar" ng-style="{ 'width': uploads.progress + '%' }"></div>
							</div>
							<div class="text-center">
								<span>Uploading: {[ uploads.progress  ]}%</span>
								<span>
									<a type="button" style="z-index: 100000" class="btn btn-xs btn-danger" ng-click="abort('{{ UPLOAD_AVATAR }}')">
										Cancel
									</a>
								</span>
							</div>
						</div>
					</div>

					<div  ng-if="uploads.status == 2 ? true : false" class="drop-zone custom-dropzone-height success">

						<div class="content custom-content" style="margin-top: 15px;">
							
						  	<img ng-src="{[ details.upload.photo_url ]}" class="img-responsive" style="max-height:150px;margin:0 auto;" />
							<div class="text-center">
								<a class="btn btn-xs btn-danger" ng-click="deleteImage(details.upload.id)">Delete</a>
							</div>
						</div>
					</div>
				</div>
			</div>
			{{-- <div>
				<label for="started_date">Image URL</label>
	        	<input type="text" ng-model="details.cover_image" id="image_url" placeholder="Use Image URL" name="image_url" class="form-control">
			</div> --}}
	</div>
	
</div>