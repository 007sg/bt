@extends('backend.common.layouts.main-login')

@section('content')

<div class="login-form row">
    <div class="col-sm-12 text-center login-header">
        {{-- <img src="{{ asset('assets/img/logo/logo.png')}}"> --}}
        LOGO
    </div>
    
    <div class="col-sm-12">
        <div class="login-body">
            <div class="progress hidden" id="login-progress">
                <div class="progress-bar progress-bar-success progress-bar-striped active" role="progressbar" aria-valuenow="100" aria-valuemin="0" aria-valuemax="100" style="width: 100%">
                    Log In...
                </div>
            </div>

            {{-- Login Error Message Response --}}
            @if($errors->has())

                <div class="alert alert-danger fade in text-left m-t-10">
                    <button class="close" data-dismiss="alert"><span>×</span></button>
                    @foreach ($errors->all() as $error)
                        <p><i class="fa fa-warning"></i> {{ $error }}</p>
                    @endforeach
                </div>

            @endif

            {{-- Login Success Message Response --}}
            @if(Session::get('success'))

                <div class="alert alert-success fade in text-left m-t-10">
                    <button class="close" data-dismiss="alert"><span>×</span></button>
                    <p><i class="fa fa-check"></i> {{ Session::get('success') }}</p>
                </div>

            @endif

            {{ Form::open(['accept-charset'=>'UTF-8', 'url' => $url, 'method' => 'POST']) }}
                <div class="control">
                    <input type="text" name="login" class="form-control"  placeholder="Username"/>
                </div>
                <div class="control">
                    <input type="password" class="form-control" name="password" placeholder="Password" />
                </div>
                <div class="login-button text-center">
                    <input type="submit" class="btn btn-primary" value="Log-in">
                </div>
            {{ Form::close() }}
        </div>
    </div>
</div>

@stop