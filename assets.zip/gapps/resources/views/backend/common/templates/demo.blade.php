<button uib-tooltip="Demo mode on!! (disabled)" class="btn btn-md btn-primary disabled">
 <i class="fa fa-eye-slash"></i> Demo mode on!! (disabled)
</button>