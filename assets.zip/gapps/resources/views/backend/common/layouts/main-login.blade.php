<!DOCTYPE html>
<html>

<head>
    <title>{{ @$configuration['site_title'] }} | {{ @$configuration['site_description'] }}</title>

    <meta name="robots" content="noindex">
    {{-- CSRF Protection --}}
    <meta name="_token" content="{{ csrf_token() }}">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Fonts -->
    <link href='http://fonts.googleapis.com/css?family=Roboto+Condensed:300,400' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Lato:300,400,700,900' rel='stylesheet' type='text/css'>

    <!-- CSS Libs -->
    @include('backend.common.assets.css')
</head>

<body class="quotes-blue login-page">
<div class="container">
    <div class="login-box">
        <div>
            @yield('content')
        </div>
    </div>
</div>
           
{{-- Include JS Files --}}
@include('backend.common.assets.js')

@yield('scripts')
</body>

</html>