<!DOCTYPE html>
<html>

<head>
    <title>{{ @$configuration['site_title'] }} | {{ @$configuration['site_description'] }} </title>
    {{-- CSRF Protection --}}
    <meta name="_token" content="{{ csrf_token() }}">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- Fonts -->
    <link href='http://fonts.googleapis.com/css?family=Roboto+Condensed:300,400' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Lato:300,400,700,900' rel='stylesheet' type='text/css'>

    <!-- CSS Libs -->
    @include('backend.common.assets.css')
</head>

<body class="cms-black getvideograbber-cms" ng-app="BackendApp">
<div class="app-container expanded">
    <div class="row content-container">
        @include('backend.common.layouts.partials.header')
         @include('backend.common.layouts.partials.sidebar')
        <!-- Main Content -->
        <div class="container-fluid">
            <div class="side-body padding-top">
                <div class="row">
                    @yield('content')
                </div>
            </div>
        </div>
    </div>
    @include('backend.common.layouts.partials.footer')
<div>

{{-- variables --}}
@include('backend.common.layouts.partials.vars')

{{-- Include JS Files --}}
@include('backend.common.assets.js')

<script type="text/javascript">
    $(function() {
      $(".navbar-expand-toggle").click(function() {
        $(".app-container").toggleClass("expanded");
        return $(".navbar-expand-toggle").toggleClass("fa-rotate-90");
      });
      return $(".navbar-right-expand-toggle").click(function() {
        $(".navbar-right").toggleClass("expanded");
        return $(".navbar-right-expand-toggle").toggleClass("fa-rotate-90");
      });
    });

    $(function() {
      return $(".side-menu .nav .dropdown").on('show.bs.collapse', function() {
        return $(".side-menu .nav .dropdown .collapse").collapse('hide');
      });
    });
</script>
@yield('scripts')
</body>

</html>