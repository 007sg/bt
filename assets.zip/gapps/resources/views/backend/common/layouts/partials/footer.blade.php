<footer class="app-footer">
    <div class="wrapper">
        <a  href="{{ url('/') }}" title="{{ @$configuration['site_title'] }}" />
          <strong style="color: #4d4d4d !important;">
            {!! @$configuration['site_name'] !!}
          </strong>
        </a>
      by <a href="{{ @$configuration['site_author_link'] }}" title="{{ @$configuration['site_author'] }}" target="_blank"> {{ @$configuration['site_author'] }}</a>.
    </div>
</footer>