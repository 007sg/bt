<div class="side-menu">
    <nav class="navbar navbar-default" role="navigation">
        <div class="side-menu-container">
            <div class="navbar-header">{{-- background-color: #f5f5f5 --}};
                <a class="navbar-brand" href="{{ url('/') }}">
                    <div class="title">
                        <img src="{{ asset('assets/img/logo/logo.png') }}" alt="{{ @$configuration['site_title'] }}"/>
                    </div>
                </a>
                <button type="button" class="navbar-expand-toggle pull-right visible-xs">
                    <i class="fa fa-times icon"></i>
                </button>
            </div>
            <ul class="nav navbar-nav">
                <li class="{{ active_link('backend.index') }}">
                    <a href="{{ route('backend.index') }}">
                        <span class="icon fa fa-tachometer"></span><span class="title">Dashboard</span>
                    </a>
                </li>


                <li class="#">
                    <a href="#">
                        <span class="icon fa fa-book"></span><span class="title">Pages</span>
                    </a>
                </li>
                <li class="panel panel-default dropdown {{ isset($is_settings) ? 'active' : ''}}">
                    <a data-toggle="collapse" href="#settings">
                        <span class="icon fa fa-cogs"></span><span class="title"> Settings</span>
                    </a>
                    <!-- Dropdown level 1 -->
                    <div id="settings" class="panel-collapse collapse {{ isset($is_settings) ? 'in' : ''}}">
                        <div class="panel-body">
                            <ul class="nav navbar-nav">
                                <li class="#">
                                    <a href="#"><i class="fa fa-cog icon"></i> General</a>
                                </li>
                                <li class="#">
                                    <a href="#"><i class="fa fa-money icon"></i> Ads Management</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </li>


                @if($isDemo != false)
                    <li class="text-center">
                        <button class="btn btn-sm  btn-danger" >
                           <i class="fa fa-warning"></i> <u>DEMO MODE ENABLED!!!! </u> <i class="fa fa-warning"></i>
                        </button>
                    </li>
                @endif
            </ul>
        </div>
        <!-- /.navbar-collapse -->
    </nav>
</div>