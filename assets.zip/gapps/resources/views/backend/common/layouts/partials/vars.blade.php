<script type="text/javascript">
    window.MyCMS  			 = (window.MyCMS || {});
    window.MyCMS.Vars        = (window.MyCMS.Vars || {});
    window.MyCMS.Resources   = (window.MyCMS.Resources || {});
    window.MyCMS.Backend   	 = (window.MyCMS.Backend || {});

    // current user_id
    window.MyCMS.user_id = '{{ @$userDetails->id }}';
    window.MyCMS.email   = '{{ @$userDetails->email }}';
</script>