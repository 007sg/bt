 {{-- Vendor Files --}}
<script type="text/javascript" src="{{ elixit('assets/js/vendor.js') }}"></script>
<script type="text/javascript" src="{{ elixit('assets/js/tinymce/tinymce.min.js') }}"></script>

<script type="text/javascript" src="{{ elixit('assets/js/common/base.js') }}"></script>
<script type="text/javascript" src="{{ elixit('assets/js/common/modules/angular-mod.js') }}"></script>



{{-- backend app.js --}}

@if(!isset($is_login))
	<script type="text/javascript" src="{{ elixit('assets/js/backend/app.js') }}"></script>
@endif