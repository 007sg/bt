{{-- Vendor Files --}}
<link rel="stylesheet" href="{{ elixit('assets/css/vendor.css') }}"/>