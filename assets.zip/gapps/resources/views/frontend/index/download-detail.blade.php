@extends('frontend.layouts.main')

@section('stylesheets')
<style type="text/css">
.clock:before,
.count:after{
	content:'';
	position:absolute;
}
.clock-wrap{
	margin:auto;
	width: 190px;
    height: 180px;
	/*margin-top:100px;*/
	position:relative;
	border-radius:50px;
	background-color:#fff;
	box-shadow:0 0 15px rgba(0,0,0,.15);
}
.clock{
    top: 70%;
    left: 67%;
    width: 100px;
    height: 100px;
    border-radius: 50%;
    position: absolute;
    margin-top: -83px;
    margin-left: -83px;
	background-color:#feeff4;
}
.clock:before{
	top:50%;
	left:50%;
	width:120px;
	height:120px;
	margin-top:-60px;
	margin-left:-60px;
	border-radius:inherit;
	background-color:#ec366b;
	box-shadow:0 0 15px rgba(0,0,0,.15), 0 0 3px rgba(255,255,255,.75) inset;
	/*border:1px solid rgba(255,255,255,.1);*/
}
.count{
	width:100%;
	color:#fff;
	height:100%;
	padding:50px;
	font-size:32px;
	font-weight:500;
	line-height:50px;
	position:absolute;
	text-align:center;
}
.count:after{
	width:100%;
	display:block;
	font-size:18px;
	font-weight:300;
	line-height:18px;
	text-align:center;
	position:relative;
}
.count.sec:after{content:'sec'}
.count.min:after{content:'min'}
</style>
@stop
@section('content')

<div class="container">
<div class="container">
	<div class="row justify-content-md-center">
		<div class="col-12 col-sm-12 col-md-12">

		    <div class="card ripple" >
			    <div style="padding: 10px;">

			      	<div class="row no-gutters">
			      		<div class="col-12 col-sm-12 col-md-3 app-image text-center">
			          		{{-- <img class="img-fluid" src="{{ $detail['cover_image'] }}" title="{{ $detail['title'] }}"> --}}
			              <img class="b-lazy" 
			                 src="{{ asset('assets/img/ajax-loader.gif') }}"
			                 data-src="{{ $detail['cover_image'] }}"
			                 alt="{{ $detail['title'] }}" 
			              />
			          	</div>

			          	<div class="col-12 col-sm-12 col-md-9 m-t-30" style="padding: 0 20px">
			          		<div class="row no-gutters">
			          			<div class="col-12 col-sm-6">
			          				<h2>{{ $detail['title'] }}</h2>
					          		<label>
					          			By <a href="{{ $detail['developer']['link'] }}" title="By {{ $detail['developer']['name'] }}">
					          				{{ $detail['developer']['name'] }}
					          			</a>
					          		</label>
					          		<p>
					          			{{ @$detail['short_summary'] }}
					          		</p>
			          			</div>
			          			<div class="col-12 col-sm-6 text-right">
			          				<p>
										
										<div class="card">
			                                <div class="card-block">
			                                    <div class="h5 m-b-0">
			                                    	Redirecting after <i class="icon-speedometer"></i> <span id="timer">0</span> sec(s)
			                                    </div>
			                                    <small class="text-muted text-uppercase font-weight-bold">Remaining Time</small>
			                                </div>
			                            </div>
			          				</p>
			          			</div>
			          		</div>
			          	</div>
			      	</div>

			    </div>
			</div>
		    
	    </div>
	    
	</div>
	<hr/>
  	@include('frontend.index.render')
</div>
</div>


@stop

@section('scripts')

<script type="text/javascript">
  $(document).ready(function($){
  	Blazy();

    var count = 6;
	var redirect = "{{ $detail['app_link'] }}";
	  
	function countDown(){
	    var timer = document.getElementById("timer");
	    if(count > 0){
	        count--;
	        timer.innerHTML = count;
	        setTimeout(countDown, 1000);
	    }else{
	        window.location.href = redirect;
	    }
	}
	countDown();
  });
</script>
@stop