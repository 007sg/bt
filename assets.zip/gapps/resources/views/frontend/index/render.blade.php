@if(isset($app) && count($app) > 0)
@foreach($app as $top)
  <div class="row">
    <div class="col-6 col-sm-6 col-md-6 ">
      <h5 class="pull-left">{{ $top['name'] }}</h5>
    </div>
    <div class="col-6 col-sm-6 col-md-6 ">
      <a href="{{ @$top['link'] }}" title="{{ @$top['name'] }}" class="btn btn-success pull-right" style=" margin-bottom: 10px;">
        See More
      </a>
    </div>
  </div>
  <div class="row top-apps">
    @foreach($top['apps'] as $key => $app)
        
        <div class="col-6 col-sm-3 col-md-2">
          <div class="card" >
            <div style="padding: 10px;" class="card-img-holder">
              <a href="{{ $app['detail_url'] }}" title="{{ $app['title']}}">
              <img class="b-lazy" 
                   src="{{ asset('assets/img/ajax-loader.gif') }}"
                   data-src="{{ $app['image']['large'] }}"
                   data-src-small="{{ $app['image']['small'] }}"
                   alt="{{ $app['title']}}"
                   style="padding: 2px;border-radius: 10px;" 
              />
              </a>
            </div>
            <div class="card-block" style="padding: .5rem;background: #fff;    white-space: nowrap;overflow: hidden;    width: 95%;">
                <p>
                {{ ++$key }}. <a href="{{ $app['detail_url'] }}" title="{{ $app['title']}}">{{ $app['title']}}</a> <br/>
                <span>
                  <small class="pull-left">
                  <a href="{{ $app['developer']['link'] }}" style="color: #263238;">
                    {{ truncate($app['developer']['name'],8,false,'..') }}
                  </a>
                  </small>
                  <small  class="text-success pull-right" >{{ $app['price'] }}</small>
                  </span>
                </p>
            </div>
          </div>
        </div>

    @endforeach
  </div>
@endforeach

@else
<div class="card card-inverse card-danger">
    
    <div class="card-block">
        {{ trans('frontend.common.no_apps') }}
    </div>
</div>
@endif