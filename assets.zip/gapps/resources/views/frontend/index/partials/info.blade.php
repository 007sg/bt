<div class="card ripple" >
    <div style="padding: 10px;">

      	<div class="row no-gutters">
      		<div class="col-12 col-sm-12 col-md-3 app-image text-center">
          		{{-- <img class="img-fluid" src="{{ $detail['cover_image'] }}" title="{{ $detail['title'] }}"> --}}
              <img class="b-lazy" 
                 src="{{ asset('assets/img/ajax-loader.gif') }}"
                 data-src="{{ $detail['cover_image'] }}"
                 alt="{{ $detail['title'] }}" 
              />
          	</div>

          	<div class="col-12 col-sm-12 col-md-9 m-t-30" style="padding: 0 20px">
          		<div class="row no-gutters">
          			<div class="col-12 col-sm-6">
          				<h2>{{ $detail['title'] }}</h2>
		          		<label>
		          			By <a href="{{ $detail['developer']['link'] }}" title="By {{ $detail['developer']['name'] }}">
		          				{{ $detail['developer']['name'] }}
		          			</a>
		          			 / 
		          			<a href="{{ $detail['category']['link'] }}" title="{{ $detail['category']['name'] }}">
		          				{{ $detail['category']['name'] }}
		          			</a>
		          		</label>
		          		<p>
		          			{{ @$detail['short_summary'] }}
		          		</p>
          			</div>
          			<div class="col-12 col-sm-6 text-right">
          				<p>
          					<a href="{{ $detail['app_url'] }}" class="btn btn-success">
	          					<i class="fa fa-android"></i>&nbsp; {{ trans('frontend.index.install_game') }}
	          				</a>
          				</p>
          				<p>
	          				<div class="addthis_inline_share_toolbox"></div>
                        </p>
          			</div>
          		</div>
          		<hr/>
          		<div>
          			<p class="description">
          				<h6>{{ trans('frontend.index.additional_information') }}</h6>

          				<div class="row no-gutters">
	          				<div class="col-12 col-sm-6 col-md-6">
		          				<ul class="list-unstyled">
									<li><b>{{ trans('frontend.index.current_version') }}:</b> {{ $detail['current_version'] }}</li>
									<li><b>{{ trans('frontend.index.updated') }}:</b> {{ $detail['updated_at'] }}</li>
									<li><b>{{ trans('frontend.index.required_android') }}:</b> {{ $detail['required_android'] }}</li>
								</ul>
							</div>

							<div class="col-12 col-sm-6 col-md-6">
		          				<ul class="list-unstyled">
									<li><b>{{ trans('frontend.index.installs') }}:</b> {{ $detail['installs'] }}</li>
									{{-- <li><b>Updated:</b> 2017-05-17</li> --}}
								</ul>
							</div>
						</div>
          			</p>
          		</div>
          	</div>
      	</div>

    </div>
</div>