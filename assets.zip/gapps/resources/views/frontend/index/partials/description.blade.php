<div class="card ripple" >
    <div style="padding: 30px;">
      	<h4>{{ trans('frontend.index.description') }}</h4>
      	<hr/>
  		
  		<p class="description">
				{!! nl2br(@$detail['description']) !!}
			</p>
    </div>
</div>