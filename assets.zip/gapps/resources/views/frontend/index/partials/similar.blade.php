@if(@$detail['similar_apps'])
    
    @if(count($detail['similar_apps']) > 0)
        <label>{{ trans('frontend.index.similar') }} </label>
        {{-- <button class="btn btn-block btn-sm btn-success" style=" margin-bottom: 10px;">See More</button> --}}
        <br/>

        <div class="row no-gutters">

            @foreach(@$detail['similar_apps'] as $key => $app)
            <div class="col-6 col-sm-4 col-md-12">
                <div class="card ripple" >
                    <div style="padding: 10px;">
                        
                        <div class="col-12 col-sm-12 col-md-12 app-image text-center">
                            <a href="{{ $app['detail_url'] }}" title="{{ $app['title']}}">
                            <img class="b-lazy" 
                                   src="{{ asset('assets/img/ajax-loader.gif') }}"
                                   data-src="{{ $app['image']['large'] }}"
                                   data-src-small="{{ $app['image']['small'] }}"
                                   alt="{{ $app['title']}}"
                                   style="padding: 2px;border-radius: 10px;" 
                              />
                            </a>
                        </div>
                        <div class="card-block" style="padding: .5rem;background: #fff;white-space: nowrap;overflow: hidden;width: 100%;">
                            <p>
                                {{ ++$key }}. <a href="{{ $app['detail_url'] }}" title="{{ $app['title']}}">{{ $app['title']}}</a> <br/>
                                <span>
                                    <small class="pull-left">
                                        <a href="{{ $app['developer']['link'] }}" style="color: #263238;">
                                            {{ truncate($app['developer']['name'],8,false,'..') }}
                                        </a>
                                    </small>
                                    <small  class="text-success pull-right" >{{ $app['price'] }}</small>
                                </span>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
            @endforeach
       
        </div>
    @endif
@endif