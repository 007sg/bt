@extends('frontend.layouts.main')

@section('stylesheets')
<style type="text/css">
  .top-apps .card-block a {
      color: #383838 !important;
  }
  .top-apps .card-block a:hover {
      color: #737373 !important;
  }

  .top-apps .card-img-holder:hover {
        background: #cecece;
  }
</style>
@stop
@section('content')

<div class="container">

@if(isset($list) && count($list) > 0)
  <div class="row">
    <div class="col-12 col-sm-12 col-md-12 ">
      <h5 >{{ $developerId }}</h5>
    </div>
  </div>
  <div class="row ">
    @foreach($list as $key => $app)
        
        <div class="col-6 col-sm-3 col-md-2">
          <div class="card" >
            <div style="padding: 10px;" class="card-img-holder">
              <img class="b-lazy" 
                   src="{{ asset('assets/img/ajax-loader.gif') }}"
                   data-src="{{ $app['image']['large'] }}"
                   data-src-small="{{ $app['image']['small'] }}"
                   alt="{{ $app['title']}}"
                   style="padding: 2px;border-radius: 10px;" 
              />
            </div>
            <div class="card-block" style="padding: .5rem;background: #fff;    white-space: nowrap;overflow: hidden;    width: 95%;">
                <p>
                {{ ++$key }}. <a href="{{ $app['detail_url'] }}" title="{{ $app['title']}}">{{ $app['title']}}</a> <br/>
                <span>
                  <small class="pull-left">
                    <a href="{{ $app['developer']['link'] }}" title="{{ $app['developer']['name'] }}" style="color: #5a5a5a !important;">
                      {{ truncate($app['developer']['name'],8,false,'..') }}
                    </a>
                  </small>
                  <small  class="text-success pull-right" >{{ $app['price'] }}</small>
                  </span>
                </p>
            </div>
          </div>
        </div>

    @endforeach
  </div>

@else
<div class="card card-inverse card-danger">
    
    <div class="card-block">
        {{ trans('frontend.common.no_apps') }}
    </div>
</div>
@endif

</div>


@stop

@section('scripts')

<script type="text/javascript">
  $(document).ready(function($){
      // Initialize
      Blazy();
  });
</script>
@stop