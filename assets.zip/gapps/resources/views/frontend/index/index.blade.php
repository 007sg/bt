@extends('frontend.layouts.main')

@section('content')

<div class="container">
  @include('frontend.index.render')
</div>


@stop

@section('scripts')

<script type="text/javascript">
  $(document).ready(function($){
      // Initialize
      Blazy();
  });
</script>
@stop