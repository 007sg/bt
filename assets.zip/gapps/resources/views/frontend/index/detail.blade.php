@extends('frontend.layouts.main')

@section('title')
{{ $detail['title'] }} | {{ trans('frontend.general.site_title') }}
@stop

@section('meta_keywords')
{{ isset($detail['seo_keywords']) ? $detail['seo_keywords'] : trans('frontend.general.site_keywords') }}@stop

@section('meta_description')
{{ @$detail['short_summary'] }}@stop

@section('meta_item_name')
{{ $detail['title'] }}@stop

@section('meta_item_desc')
{{ $detail['short_summary'] }}@stop

@section('meta_image')
{{ $detail['cover_image'] }}@stop

@section('content')

<main class="flex-between align-center app-detail">
    

    <div class="container">
      <div class="row justify-content-md-center">
        <div class="col-12 col-sm-12 col-md-10">

            @include('frontend.index.partials.info')
            @include('frontend.index.partials.screenshots')
            @include('frontend.index.partials.description')
            @include('frontend.index.partials.reviews')
            
            {{-- DISQUS --}}
            <div class="card ripple" >
                <div style="padding: 30px;">
                    <div id="disqus_thread"></div>
                </div>
            </div>
            
        </div>
        
        <div class="col-12 col-sm-12 col-md-2">
            @include('frontend.index.partials.similar')
            @include('frontend.index.partials.more-from-developer')
        </div>
      </div>
      
    </div>

</main>

@stop

@section('scripts')

<!-- Go to www.addthis.com/dashboard to customize your tools --> 
<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid={{ env('ADDTHIS_CODE') }}"></script> 


<script type="text/javascript">
    $(document).ready(function() {
        Blazy();
        $('.owl-carousel').owlCarousel({
                loop: true,
                autoplay:true,
                items : 3,
                slideSpeed : 2000,
                nav: true,
                dots: true,
                loop: true,
                navText: ['<svg width="100%" height="100%" viewBox="0 0 11 20"><path style="fill:none;stroke-width: 1px;stroke: #000;" d="M9.554,1.001l-8.607,8.607l8.607,8.606"/></svg>','<svg width="100%" height="100%" viewBox="0 0 11 20" version="1.1"><path style="fill:none;stroke-width: 1px;stroke: #000;" d="M1.054,18.214l8.606,-8.606l-8.606,-8.607"/></svg>'],

                responsiveClass: true,

                responsive: {
                  0: {
                    items: 1,
                    nav: true
                  },
                  600: {
                    items: 3,
                    nav: false
                  },
                  1000: {
                    items: 3,
                    nav: true
                  }
                }
        });


       
    });


/**
*  RECOMMENDED CONFIGURATION VARIABLES: EDIT AND UNCOMMENT THE SECTION BELOW TO INSERT DYNAMIC VALUES FROM YOUR PLATFORM OR CMS.
*  LEARN WHY DEFINING THESE VARIABLES IS IMPORTANT: https://disqus.com/admin/universalcode/#configuration-variables*/

var disqus_config = function () {
this.page.url = '{{ @$currentURl }}';  // Replace PAGE_URL with your page's canonical URL variable
this.page.identifier = '{{ @$appId }}'; // Replace PAGE_IDENTIFIER with your page's unique identifier variable
};

(function() { // DON'T EDIT BELOW THIS LINE
var d = document, s = d.createElement('script');
s.src = '//{{ env('DISQUS_CODE') }}.disqus.com/embed.js';
s.setAttribute('data-timestamp', +new Date());
(d.head || d.body).appendChild(s);
})();
</script>

@stop