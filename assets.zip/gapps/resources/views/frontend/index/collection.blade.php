@extends('frontend.layouts.main')

@section('stylesheets')
<style type="text/css">
  .top-apps .card-block a {
      color: #383838 !important;
  }
  .top-apps .card-block a:hover {
      color: #737373 !important;
  }

  .top-apps .card-img-holder:hover {
        background: #cecece;
  }
</style>
@stop
@section('content')

<div class="container">


@if(isset($topApps))
<div class="row">


  <div class="col-6 col-sm-6 col-md-6 ">
    @if(isset($searchQ))
      <h2>Search Results for : <small><strong><u> {{ $searchQ }}</u> </strong></small></h2>
    @endif

    <h5 class="pull-left">{{ @$topApps['name'] }}</h5>
  </div>
  
</div>
<div class="row top-apps">
  @foreach($topApps['apps'] as $key => $app)
      
      <div class="col-6 col-sm-3 col-md-2">
        <div class="card" >
          <div style="padding: 10px;" class="card-img-holder">
            <a href="{{ $app['developer']['link'] }}" style="color: #263238;">
            <img class="b-lazy" 
                 src="{{ asset('assets/img/ajax-loader.gif') }}"
                 data-src="{{ $app['image']['large'] }}"
                 data-src-small="{{ $app['image']['small'] }}"
                 alt="{{ $app['title']}}"
                 style="padding: 2px;border-radius: 10px;" 
            />
            </a>
          </div>
          <div class="card-block" style="padding: .5rem;background: #fff;    white-space: nowrap;overflow: hidden;    width: 95%;">
              <p>
              {{ ++$key }}. <a href="{{ $app['detail_url'] }}" title="{{ $app['title']}}">{{ $app['title']}}</a> <br/>
              <span>
                <a href="{{ $app['developer']['link'] }}" style="color: #263238;">
                    {{ truncate($app['developer']['name'],8,false,'..') }}
                </a>
                <small  class="text-success pull-right" >{{ $app['price'] }}</small>
                </span>
              </p>
          </div>
        </div>
      </div>

  @endforeach
</div>

@else
<div class="card card-inverse card-danger">
    
    <div class="card-block">
        {{ trans('frontend.common.no_apps') }}
    </div>
</div>
@endif

</div>


@stop

@section('scripts')

<script type="text/javascript">
  $(document).ready(function($){
      // Initialize
      Blazy();
  });
</script>
@stop