@extends('frontend.layouts.main')

@section('stylesheets')
<style type="text/css">

</style>
@stop
@section('content')

<div class="container">
  <div class="animated fadeIn">
        <div class="row">
            <div class="col-sm-12 col-md-12">
                <div class="card">
                    <div class="card-header">
                        {{ trans('frontend.footer.about_us') }}
                    </div>
                    <div class="card-block">
                        Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat.
                    </div>
                </div>
            </div>
        </div>
        
    </div>
</div>


@stop

@section('scripts')

<script type="text/javascript">
  $(document).ready(function($){
     
  });
</script>
@stop