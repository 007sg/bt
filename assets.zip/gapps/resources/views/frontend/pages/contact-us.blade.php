@extends('frontend.layouts.main')

@section('stylesheets')
<style type="text/css">

</style>
@stop
@section('content')

<div class="container">
  <div class="animated fadeIn">
        <div class="row">
            <div class="col-sm-12 col-md-12">
                <div class="card">
                    <div class="card-header">
                         {{ trans('frontend.footer.contact_us') }}
                    </div>
                    <div class="card-block">

                        <div class="row">
                            <div class="col-sm-6 offset-sm-3">

                                @if(Session::has('message'))
                                    <div class="alert alert-succss">
                                      {{Session::get('message')}}
                                    </div>
                                @endif
                                <ul>
                                    @foreach($errors->all() as $error)
                                        <li>{{ $error }}</li>
                                    @endforeach
                                </ul>

                                {{ Form::open(['url' => route('page.submit.contact'),'method' => 'POST']) }}
                                  <div class="form-group">
                                      <label for="name">{{ trans('frontend.contact.name') }}</label>
                                      <input type="text" class="form-control" id="name" name="name" placeholder="Enter your name">
                                  </div>

                                  <div class="form-group">
                                      <label for="email_address">{{ trans('frontend.contact.email') }}</label>
                                      <input type="text" class="form-control" id="email_address" name="email_address" placeholder="Enter your email address">
                                  </div>

                                  <div class="form-group">
                                      <label for="message">{{ trans('frontend.contact.message') }}</label>
                                      <textarea id="message"  class="form-control" name="message" placeholder="Enter your message" style="height: 200px;"></textarea>
                                  </div>


                                  <div class="form-group">
                                    <button type="submit" class="btn btn-sm btn-primary">
                                      <i class="fa fa-dot-circle-o"></i> {{ trans('frontend.contact.submit') }}
                                    </button>
                                  </div>
                                {{ Form::close() }}

                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
        
    </div>
</div>


@stop

@section('scripts')

<script type="text/javascript">
  $(document).ready(function($){
     
  });
</script>
@stop