<div class="sidebar">
    <nav class="sidebar-nav">
        <ul class="nav">

            @if($sidebarMenu)

                @foreach($sidebarMenu as $menu)
                    <li class="nav-title">
                        {{ $menu['name'] }}
                    </li>

                    @foreach($menu['item'] as $item)
                        <li class="nav-item">
                            <a class="nav-link" href="{{ $item['link'] }}">
                              <i class="icon-speedometer"></i> {{ $item['name'] }}
                            </a>
                        </li>
                    @endforeach

                @endforeach

            @endif
            
        </ul>
    </nav>
</div>