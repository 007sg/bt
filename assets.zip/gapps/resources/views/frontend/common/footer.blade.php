<footer class="app-footer">
    {!! trans('frontend.footer.copyright') !!}
      <span class="float-right">
        <a href="{{ url('/') }}">
            {{ trans('frontend.footer.home') }}
        </a> |
        <a href="{{ route('page.about') }}">
            {{ trans('frontend.footer.about_us') }}
        </a> |
        <a href="{{ route('page.dmca') }}">
            {{ trans('frontend.footer.dmca') }}
        </a> |
        <a href="{{ route('page.privacy.policy') }}">
            {{ trans('frontend.footer.privacy_policy') }}
        </a> |
        <a href="{{ route('page.contactus') }}">
            {{ trans('frontend.footer.contact_us') }}
        </a>
    </span>

</footer>