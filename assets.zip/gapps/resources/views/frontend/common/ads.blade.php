{{-- START TOP BANNER --}}
@section('ads_top_banner')
	
	<div class="col-12 col-md-auto">
		<div class="card ripple text-center" style="min-height: 90px;">
	    
	      	{{-- PASTE YOUR ADS FOR TOP BANNER HERE  --}}
	      	ADS TOP BANNER HERE
	      	
	    </div>
	</div>


@stop
{{-- END TOP BANNER --}}



{{-- START BOTTOM BANNER --}}
@section('ads_bottom_banner')

	<div class="col-12 col-md-auto">
		<div class="card ripple text-center" style="min-height: 90px;">
	   	{{-- PASTE YOUR ADS FOR BOTTOM BANNER HERE  --}}
	   	ADS BOTTOM BANNER HERE
		</div>
	</div>

@stop
{{-- END BOTTOM BANNER --}}



{{-- START SIDEBAR BANNER --}}
@section('ads_sidebar_banner')
	<div class="col-6 col-sm-4 col-md-12">
	        <div class="card ripple" >
			    {{-- PASTE YOUR ADS FOR SIDEBAR BANNER HERE  --}}
			   	ADS SIDEBAR BANNER HERE
			</div>
	</div>
@stop
{{-- END SIDEBAR BANNER --}}