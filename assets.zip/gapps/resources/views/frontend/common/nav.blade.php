<ol class="breadcrumb">
    <li class="breadcrumb-item">
        <div>
            {{ Form::open(['accept-charset'=>'UTF-8', 'url' => route('frontend.search') , 'method' => 'GET','id'=>'main-search']) }}
                <div class="input-group">
                   <input type="text" class="form-control" name="q" placeholder="{{ trans('frontend.index.search') }}">
                </div>
            {{ Form::close() }}
        </div>
    </li>
    
    <li class="categories breadcrumb-menu d-sm-down-none">
        <div class="btn-group" role="group" aria-label="Button group with nested dropdown">
            <a class="nav-link dropdown-toggle nav-link" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
                <span class="d-sm-down-none"> {{ trans('frontend.menu.category') }} </span>
            </a>
            <div class="category_list dropdown-menu dropdown-menu-right">

                <ul id="category" class="list-unstyled">
                    @foreach($categories as $category)
                        <li class="dropdown-item">
                            <a href="{{ $category['link'] }}" >
                                <i class="fa fa-google" aria-hidden="true"></i> {{ $category['name'] }}
                            </a>
                        </li>
                    @endforeach
                </ul>
                
            </div>
        </div>
        @if(isset($sidebarMenu))
            @foreach($sidebarMenu as $menu)

                <div class="btn-group" role="group" aria-label="Button group with nested dropdown">
                    <a class="nav-link dropdown-toggle nav-link" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">
                        <span class="d-sm-down-none">{{ $menu['name'] }}</span>
                    </a>

                    <div class="dropdown-menu dropdown-menu-right">
                        @foreach($menu['item'] as $item)
                            <a class="dropdown-item" href="{{ $item['link'] }}">
                                <i class="fa fa-link" aria-hidden="true"></i> {{ $item['name'] }}
                            </a>
                        @endforeach
                    </div>
                </div>    
            @endforeach
        @endif
    </li>
</ol>