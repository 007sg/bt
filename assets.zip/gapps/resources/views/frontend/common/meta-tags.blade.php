		<meta name="keywords" content="@yield('meta_keywords',trans('frontend.general.site_keywords'))"/>
		<meta name="description" content="@yield('meta_description',trans('frontend.general.site_description'))"/>
		<meta name="author" content="@yield('author',trans('frontend.general.site_author'))"/>

		<!-- Open Graph Tags -->
		<meta property='og:type' content='website' />
		<meta property='og:url' content='{{ url('/') }}' />
		<meta property='og:title' content='@yield('meta_item_name',trans('frontend.general.site_title'))' />
		<meta property='og:description' content='@yield('meta_item_desc',trans('frontend.general.site_description'))' />
		<meta property='og:image' content='@yield('meta_image')' />

		<meta name='twitter:card' content='summary_large_image'>
		<meta name='twitter:site' content='@dcm'>
		<meta name='twitter:title' content='@yield('meta_item_name',trans('frontend.general.site_author'))'>
		<meta name='twitter:description' content='@yield('meta_item_desc',trans('frontend.general.site_description'))'>
		<meta name='twitter:creator' content='@dcm'>
		<meta name='twitter:image:src' content='@yield('meta_image')'>
		<meta name='twitter:domain' content='{{ url('/') }}'>