<!DOCTYPE html>
<html lang="en">
<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
   
    <link rel="shortcut icon" href="{{ asset('assets/img/favicon.png') }}">
    @include('frontend.common.meta-tags')

    <title>@yield('title',trans('frontend.general.site_title'))</title>

    <!-- Main styles for this application -->
    <link href="{{ asset('assets/css/vendor.css') }}" rel="stylesheet">
    <link href="{{ asset('assets/css/frontend/app.css') }}" rel="stylesheet">

    @yield('stylesheets')

</head>

<body class="app header-fixed sidebar-hidden aside-menu-fixed aside-menu-hidden">

    @include('frontend.common.analytics')
    @include('frontend.common.ads')

    <header class="app-header navbar">
        <button class="navbar-toggler mobile-sidebar-toggler d-lg-none" type="button">☰</button>
        <a class="navbar-brand text-center" href="{{ route('frontend.index') }}"> 
            {{-- <i style="color: #71d24b;" class="fa fa-android" aria-hidden="true"></i> --}}
            <img src="{{ asset('assets/img/app-logo.png') }}" height="45" />
            {!! trans('frontend.general.site_name') !!}
        </a>
        <ul class="nav navbar-nav d-md-down-none">
            <li class="nav-item">
                <a class="nav-link navbar-toggler sidebar-toggler" href="#">☰</a>
            </li>
        </ul>
    </header>


    <div class="app-body">
        @include('frontend.common.sidebar')
        <!-- Main content -->
        <main class="main"> 
            @include('frontend.common.nav')
            <div class="container-fluid">
                <div class="container">
                  {{-- @yield('ads_top_banner') --}}
                </div>
                @yield('content')
                <div class="container">
                  {{-- @yield('ads_bottom_banner') --}}
                </div>
            </div>
            <!-- /.container-fluid -->
        </main>

    </div>
    @include('frontend.common.footer')


    <!-- Bootstrap and necessary plugins -->
    <script src="{{ asset('assets/js/vendor.js') }}"></script>

    <!-- GenesisUI main scripts -->
    <script type="text/javascript">
        /*****
        * CONFIGURATION
        */
            //Main navigation
            $.navigation = $('nav > ul.nav');

            $.panelIconOpened = 'icon-arrow-up';
            $.panelIconClosed = 'icon-arrow-down';

            //Default colours
            $.brandPrimary =  '#20a8d8';
            $.brandSuccess =  '#4dbd74';
            $.brandInfo =     '#63c2de';
            $.brandWarning =  '#f8cb00';
            $.brandDanger =   '#f86c6b';

            $.grayDark =      '#2a2c36';
            $.gray =          '#55595c';
            $.grayLight =     '#818a91';
            $.grayLighter =   '#d1d4d7';
            $.grayLightest =  '#f8f9fa';

        'use strict';

        /****
        * MAIN NAVIGATION
        */

        $(document).ready(function($){

          // Add class .active to current link
          $.navigation.find('a').each(function(){

            var cUrl = String(window.location).split('?')[0];

            if (cUrl.substr(cUrl.length - 1) == '#') {
              cUrl = cUrl.slice(0,-1);
            }

            if ($($(this))[0].href==cUrl) {
              $(this).addClass('active');

              $(this).parents('ul').add(this).each(function(){
                $(this).parent().addClass('open');
              });
            }
          });

          // Dropdown Menu
          $.navigation.on('click', 'a', function(e){

            if ($.ajaxLoad) {
              e.preventDefault();
            }

            if ($(this).hasClass('nav-dropdown-toggle')) {
              $(this).parent().toggleClass('open');
              resizeBroadcast();
            }

          });

          function resizeBroadcast() {

            var timesRun = 0;
            var interval = setInterval(function(){
              timesRun += 1;
              if(timesRun === 5){
                clearInterval(interval);
              }
              window.dispatchEvent(new Event('resize'));
            }, 62.5);
          }

          /* ---------- Main Menu Open/Close, Min/Full ---------- */
          $('.navbar-toggler').click(function(){

            if ($(this).hasClass('sidebar-toggler')) {
              $('body').toggleClass('sidebar-hidden');
              resizeBroadcast();
            }

            if ($(this).hasClass('sidebar-minimizer')) {
              $('body').toggleClass('sidebar-minimized');
              resizeBroadcast();
            }

            if ($(this).hasClass('aside-menu-toggler')) {
              $('body').toggleClass('aside-menu-hidden');
              resizeBroadcast();
            }

            if ($(this).hasClass('mobile-sidebar-toggler')) {
              $('body').toggleClass('sidebar-mobile-show');
              resizeBroadcast();
            }

          });

          $('.sidebar-close').click(function(){
            $('body').toggleClass('sidebar-opened').parent().toggleClass('sidebar-opened');
          });

          /* ---------- Disable moving to top ---------- */
          $('a[href="#"][data-top!=true]').click(function(e){
            e.preventDefault();
          });

        });

        /****
        * CARDS ACTIONS
        */

        $(document).on('click', '.card-actions a', function(e){
          e.preventDefault();

          if ($(this).hasClass('btn-close')) {
            $(this).parent().parent().parent().fadeOut();
          } else if ($(this).hasClass('btn-minimize')) {
            var $target = $(this).parent().parent().next('.card-block');
            if (!$(this).hasClass('collapsed')) {
              $('i',$(this)).removeClass($.panelIconOpened).addClass($.panelIconClosed);
            } else {
              $('i',$(this)).removeClass($.panelIconClosed).addClass($.panelIconOpened);
            }

          } else if ($(this).hasClass('btn-setting')) {
            $('#myModal').modal('show');
          }

        });

        function capitalizeFirstLetter(string) {
          return string.charAt(0).toUpperCase() + string.slice(1);
        }

        function init(url) {

          /* ---------- Tooltip ---------- */
          $('[rel="tooltip"],[data-rel="tooltip"]').tooltip({"placement":"bottom",delay: { show: 400, hide: 200 }});

          /* ---------- Popover ---------- */
          $('[rel="popover"],[data-rel="popover"],[data-toggle="popover"]').popover();

        }



    </script>

    @yield('scripts')

</body>

</html>