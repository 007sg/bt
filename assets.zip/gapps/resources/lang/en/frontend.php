<?php

return [

	'general' => [

		'site_title' 		=> 'AppMarket - Android Apps in Google Play',
		'site_name'			=> '{ <strong style=""><u>AppMarket</u> </strong> } - GooglePlay',
		'site_description'  => 'AppMarket - Android Apps in Google Play',
		'site_keywords' 	=> 'AppMarket - GooglePlay',
		'site_author' 		=> 'Anthony Pillos',

   	],

   	'common' => [
   		'no_comments' => 'No Comments',
   		'see_more' => 'See More',
   		'no_apps' => 'No top Applications Found.'
   	],

   	'index' => [

		'search'            	 => 'Search from apps store...',
		'description'            => 'Descriptions',
		'install_game'           => 'Download App',
		'additional_information' => 'Additional Informations',
		'current_version'        => 'Current Version',
		'updated'                => 'Updated',
		'required_android'       => 'Requires Android',
		'installs'               => 'Installs',

		'more_from_developer' 	 => 'More From Developers',
		'reviews' 	             => 'Reviews',
		'screenshot' 	         => 'Screenshots',
		'similar' 	         	 => 'Similar Apps',

   	],

   	'menu' => [

   		'category'	=> 'Categories',

   		// TOP CHARTS
   		'top_chart'         => 'Top Charts',
	   		'top_free_apps'     => 'Top Free in Apps',
	   		'top_paid_apps'     => 'Top Paid in Apps',
	   		'top_grossing_apps' => 'Top Grossing Apps',

	   	// NEW RELEASES
   		'new_release'         => 'New Releases',
	   		'top_new_free'     => 'Top New Free',
	   		'top_new_paid'     => 'Top New Paid'
   	],

   	'contact' => [

	   	'name'    => 'Name',
	   	'email'   => 'Email Address',
	   	'message' => 'Message',
	   	'submit'  => 'Submit',

   	],
   	'footer' => [

   		'copyright'      => '© 2017 <a href="http://devcorpmanila.com" rel="nofollow">Devcorpmanila.com</a>',

   		'home'           => 'Home',
   		'about_us'       => 'About Us',
   		'dmca'           => 'DMCA',
   		'privacy_policy' => 'Privacy Policy',
   		'contact_us'     => 'Conctact Us'

   	]
];