
/**
 * Frontend App Start
 *
 * @class        FrontendApp
 * @package      MyCMS.Frontend.FrontendApp
 * @author       Anthony Pillos <me@anthonypillos.com>
 * @copyright    Copyright (c) 2016 Anthony Pillos. (http://anthonypillos.com,http://iapdesign.com,http://developers.ph)
 * @version      v1
 */

(function() {
  var FrontendApp;

  FrontendApp = (function() {
    function FrontendApp() {
      var app;
      app = angular.module('FrontendApp', ['ApiFactory', 'SystemFactory', 'ui.bootstrap', 'ui.tinymce', 'localytics.directives', 'ListingService', 'NumberOnlyDirective', 'PaginationDirective', 'FileUploaderDirective', 'UploadFactory', 'SweetAlertService', 'SystemFilter', 'KeyBindDirective', 'ngAnimate']);
      app.config([
        'blockUIConfig', function(blockUIConfig) {
          blockUIConfig.message = 'Please Wait...';
          return blockUIConfig.autoBlock = false;
        }
      ]);
      app.run(['$rootScope', function($rootScope) {}]);
      return app;
    }

    return FrontendApp;

  })();

  window.MyCMS.Frontend.FrontendApp = new FrontendApp;

}).call(this);
